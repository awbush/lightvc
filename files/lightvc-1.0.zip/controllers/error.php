<?php

class ErrorController extends AppController
{
	public function actionView($error = '404')
	{
		$this->loadView('error/' . $error);
	}
}

?>