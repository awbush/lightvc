<?php

class PageController extends AppController
{
	public function actionView($pageName = 'home')
	{
		$this->loadView('page/' . $pageName);
	}
}

?>