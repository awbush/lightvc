Visit the Web site at:
http://lightvc.anthonybush.com/

A copy of the documentation at the above site is available in the docs folder in this directory.
